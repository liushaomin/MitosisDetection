Tools for training, testing, and compressing Fast R-CNN networks.
